# Example 6
### Purpose
Understand the use of the canvas.
### Operation
By using the buttons, the circle will move on the canvas. When the circle intersects with a rectangle, the circle is moved to its initial position.
